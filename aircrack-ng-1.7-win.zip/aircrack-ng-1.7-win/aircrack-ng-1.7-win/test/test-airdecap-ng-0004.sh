#!/bin/sh

set -ef

"${abs_srcdir}/test-airdecap-ng.sh" "${abs_builddir}/.."

exit 0

